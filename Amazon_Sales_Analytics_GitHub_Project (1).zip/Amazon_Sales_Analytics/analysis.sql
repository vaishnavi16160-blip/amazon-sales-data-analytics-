-- SQLite-style analysis examples. Import cleaned_data.csv as amazon_sales.
SELECT SUM(CASE WHEN lower(Status) NOT LIKE '%cancel%' AND Qty > 0 THEN COALESCE(Amount,0) ELSE 0 END) AS eligible_sales,
COUNT(DISTINCT CASE WHEN lower(Status) NOT LIKE '%cancel%' AND Qty > 0 THEN [Order ID] END) AS eligible_orders
FROM amazon_sales;

SELECT Month, SUM(Amount) AS sales
FROM amazon_sales WHERE lower(Status) NOT LIKE '%cancel%' AND Qty > 0
GROUP BY Month ORDER BY Month;

SELECT [ship-city] AS city, SUM(Amount) AS sales, COUNT(DISTINCT [Order ID]) AS orders
FROM amazon_sales WHERE lower(Status) NOT LIKE '%cancel%' AND Qty > 0
GROUP BY [ship-city] ORDER BY sales DESC LIMIT 10;

SELECT Category, SUM(Amount) AS sales, SUM(Qty) AS quantity
FROM amazon_sales WHERE lower(Status) NOT LIKE '%cancel%' AND Qty > 0
GROUP BY Category ORDER BY sales DESC;
