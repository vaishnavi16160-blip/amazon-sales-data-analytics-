# Amazon India Sales Analytics

## Overview
Portfolio analysis of the supplied Amazon Sale Report dataset using Python/pandas for preparation, spreadsheet dashboarding, and SQL examples.

## Files
- `Amazon_Sales_Analytics_Dashboard.xlsx` — Dashboard and summary tabs (monthly, category, top cities, top states, status).
- `cleaned_data.csv` — normalized analysis-ready dataset with date, numeric fields, cancellation flag and eligible sales.
- `monthly_summary.csv`, `category_summary.csv`, `top_cities.csv`, `top_states.csv`, `status_summary.csv` — dashboard source tables.
- `analysis.sql` — sample SQL queries.
- `README.md` — documentation.

## Data
Rows: 128,975. Date range: 2022-03-31 to 2022-06-29.

## KPI definitions
- Eligible Sales: Amount sum where Status is not cancelled and Qty > 0.
- Eligible Orders: distinct Order IDs among those included rows.
- Eligible Quantity: Qty sum for non-cancelled rows.
- Average Order Value: Eligible Sales / Eligible Orders.

These are portfolio analysis definitions, not audited accounting metrics. Source data may not fully reconcile returns, refunds, taxes, or line-item allocations.

## Findings to explore
Use the dashboard to inspect month-to-month sales, category contribution, and geographic concentration. Avoid claiming causation from descriptive summaries.

## GitHub note
Before publishing, check the dataset's license and redistribution terms. If unclear, publish summary outputs and a small sample rather than the full raw customer/order dataset. Review privacy and sensitive fields before public upload.
